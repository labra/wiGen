for countries in 1 5 10 50 100 500 1000
do
 ./wigen -c $countries -g 1 --dataSets 1 -o 1 --shex --shacl --time --no-single >> obsCountries 
done